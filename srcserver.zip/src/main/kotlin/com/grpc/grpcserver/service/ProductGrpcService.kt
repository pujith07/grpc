package com.grpc.grpcserver.service

import com.graphql.graphql.proto.*
import com.grpc.grpcserver.model.Product
import com.grpc.grpcserver.repository.ProductRepository
import org.springframework.stereotype.Service

@Service
class ProductGrpcService(
    private val productRepository: ProductRepository
) {
    fun getProductByName(
        request: ProductByNameRequest?
    ): ProductGrpc? {
        val product = request?.productName?.let { productRepository.findByProductNameContaining(it).first() }
        var unitSoldSoFar: ProductGrpc? = null
        if (product != null) {
            unitSoldSoFar = ProductGrpc.newBuilder().setProductName(product.productName)
                .setProductType(product.productType)
                .setProductId(product.productId)
                .setManufacturer(product.manufacturer)
                .setPrice(product.price)
                .setUnitSoldSoFar(product.unitSoldSoFar)
                .build()
        }
        return unitSoldSoFar
    }

    fun saveProduct(
        request: ProductGrpcRequest?
    ): ProductGrpcResponse? {
        val products = mutableListOf<Product>()
        request?.productsList?.forEach { productGrpc ->
            products.add(
                productRepository.save(
                    Product(
                        productGrpc.productId,
                        productGrpc.productName,
                        productGrpc.productType,
                        productGrpc.manufacturer,
                        productGrpc.unitSoldSoFar,
                        productGrpc.price
                    )
                )
            )
        }
        val grpcList = mutableListOf<ProductGrpc>()
        products.forEach {
            grpcList.add(ProductGrpc.newBuilder()
                .setProductId(it.productId)
                .setProductName(it.productName)
                .setProductType(it.productType)
                .setManufacturer(it.manufacturer)
                .setUnitSoldSoFar(it.unitSoldSoFar)
                .setPrice(it.price).build()
            )
        }
        return ProductGrpcResponse.newBuilder().addAllProducts(grpcList).build()
    }

    fun getAllManufacturers(
        request: EmptyRequest?
    ): ManufacturerGrpcList? {
        val manufacturers = productRepository.findDistinctManufacturers()
        val manufacturerGrpcList = manufacturers.map { manufacturer ->
            ManufacturerGrpc.newBuilder()
                .setManufactureName(manufacturer)
                .build()
        }
        return ManufacturerGrpcList.newBuilder().addAllManufacturers(manufacturerGrpcList).build()
    }

}