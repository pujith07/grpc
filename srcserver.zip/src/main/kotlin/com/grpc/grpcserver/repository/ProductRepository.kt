package com.grpc.grpcserver.repository

import com.grpc.grpcserver.model.Product
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface ProductRepository : JpaRepository<Product, Int> {
    @Query("SELECT DISTINCT p.manufacturer FROM Product p")
    fun findDistinctManufacturers(): List<String>
    fun findByProductNameContaining(name: String): List<Product>
}
