package com.grpc.grpcserver.model

import jakarta.persistence.*

@Entity
@Table(name = "app_user")
data class User(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var userId: Long = 0,
    var firstName: String = "",
    var lastName: String = "",
    var gender: String = "",
    var email: String = "",
    var contact: String = "",
    var password: String = ""
)
