package com.grpc.grpcserver.service

import com.graphql.graphql.proto.ManufacturerByNameRequest
import com.graphql.graphql.proto.ManufacturerGrpc
import com.graphql.graphql.proto.ManufacturerGrpcRequest
import com.graphql.graphql.proto.ManufacturerGrpcResponse
import com.grpc.grpcserver.model.Manufacturer
import com.grpc.grpcserver.repository.ManufacturerRepository
import org.springframework.stereotype.Service

@Service
class ManufacturerGrpcService(
    private val manufacturerRepository: ManufacturerRepository
) {
    fun getManufacturerByName(
        request: ManufacturerByNameRequest?
    ): ManufacturerGrpc? {
        val manufacturer = request?.manufactureName?.let { manufacturerRepository.findByManufactureName(it).first() }
        var grpcManufacturer: ManufacturerGrpc? = null
        if (manufacturer != null) {
            grpcManufacturer = ManufacturerGrpc.newBuilder()
                .setManufactureName(manufacturer.manufactureName)
                .setManufactureId(manufacturer.manufactureId)
                .setManufactureOrigin(manufacturer.manufactureOrigin)
                .setAnnualRevenue(manufacturer.annualRevenue)
                .setNoOfProductsAvailable(manufacturer.noOfProductsAvailable)
                .setUserRatings(manufacturer.userRatings)
                .build()
        }
        return grpcManufacturer
    }

    fun saveManufacturer(
        request: ManufacturerGrpcRequest?
    ): ManufacturerGrpcResponse? {
        val manufacturers = mutableListOf<Manufacturer>()
        request?.manufacturersList?.forEach { manufacturerGrpc ->
            manufacturers.add(
                manufacturerRepository.save(
                    Manufacturer(
                        manufacturerGrpc.manufactureId,
                        manufacturerGrpc.manufactureName,
                        manufacturerGrpc.manufactureOrigin,
                        manufacturerGrpc.userRatings,
                        manufacturerGrpc.noOfProductsAvailable,
                        manufacturerGrpc.annualRevenue
                    )
                )
            )
        }
        val grpcList = mutableListOf<ManufacturerGrpc>()
        manufacturers.forEach {
            grpcList.add(ManufacturerGrpc.newBuilder()
                .setManufactureName(it.manufactureName)
                .setManufactureId(it.manufactureId)
                .setManufactureOrigin(it.manufactureOrigin)
                .setAnnualRevenue(it.annualRevenue)
                .setNoOfProductsAvailable(it.noOfProductsAvailable)
                .setUserRatings(it.userRatings)
                .build()
            )
        }
        return ManufacturerGrpcResponse.newBuilder().addAllManufacturers(grpcList).build()
    }

}