package com.grpc.grpcserver.service

import com.graphql.graphql.proto.*
import io.grpc.stub.StreamObserver
import org.springframework.stereotype.Service

@Service
class GrpcServerService(
    private val userGrpcService: UserGrpcService,
    private val productGrpcService: ProductGrpcService,
    private val manufacturerGrpcService: ManufacturerGrpcService
) : GraphQLServiceGrpc.GraphQLServiceImplBase() {


    override fun saveUser(
        request: UserGrpcRequest?,
        responseObserver: StreamObserver<UserGrpcResponse>?
    ) {
        val grpcList = userGrpcService.saveUser(request)
        responseObserver?.onNext(UserGrpcResponse.newBuilder().addAllUsers(grpcList).build())
        responseObserver?.onCompleted()
    }

    override fun validateCredentials(
        request: CredentialsRequest?,
        responseObserver: StreamObserver<CredentialsResponse>?
    ) {
        val valid: Boolean? = userGrpcService.validateUser(request)
        responseObserver?.onNext(valid?.let { CredentialsResponse.newBuilder().setIsValid(it).build() })
        responseObserver?.onCompleted()
    }

    override fun getProductByName(request: ProductByNameRequest?, responseObserver: StreamObserver<ProductGrpc>?) {
        val productByName = productGrpcService.getProductByName(request)
        responseObserver?.onNext(productByName)
        responseObserver?.onCompleted()
    }

    override fun saveProduct(request: ProductGrpcRequest?, responseObserver: StreamObserver<ProductGrpcResponse>?) {
        val productByName = productGrpcService.saveProduct(request)
        responseObserver?.onNext(productByName)
        responseObserver?.onCompleted()
    }

    override fun getManufacturerByName(
        request: ManufacturerByNameRequest?,
        responseObserver: StreamObserver<ManufacturerGrpc>?
    ) {
        val manufacturerByName = manufacturerGrpcService.getManufacturerByName(request)
        responseObserver?.onNext(manufacturerByName)
        responseObserver?.onCompleted()
    }

    override fun saveManufacturer(
        request: ManufacturerGrpcRequest?,
        responseObserver: StreamObserver<ManufacturerGrpcResponse>?
    ) {
        val saveManufacturer = manufacturerGrpcService.saveManufacturer(request)
        responseObserver?.onNext(saveManufacturer)
        responseObserver?.onCompleted()
    }
}
