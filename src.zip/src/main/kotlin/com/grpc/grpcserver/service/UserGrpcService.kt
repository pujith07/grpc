package com.grpc.grpcserver.service

import com.graphql.graphql.proto.CredentialsRequest
import com.graphql.graphql.proto.UserGrpc
import com.graphql.graphql.proto.UserGrpcRequest
import com.grpc.grpcserver.model.User
import com.grpc.grpcserver.repository.UserRepository
import org.springframework.stereotype.Service

@Service
class UserGrpcService(
    private val userRepository: UserRepository
) {
    fun saveUser(request: UserGrpcRequest?): MutableList<UserGrpc> {
        val users = mutableListOf<User>()
        request?.usersList?.forEach {
            val password = it.firstName + it.contact
            users.add(
                userRepository.save(
                    User(
                        it.userId,
                        it.firstName,
                        it.lastName,
                        it.gender,
                        it.email,
                        it.contact,
                        password
                    )
                )
            )
        }

        val grpcList = mutableListOf<UserGrpc>()
        users.forEach {
            grpcList.add(
                UserGrpc.newBuilder()
                    .setEmail(it.email)
                    .setGender(it.gender)
                    .setContact(it.contact)
                    .setFirstName(it.firstName)
                    .setLastName(it.lastName).build()
            )
        }
        return grpcList
    }

    fun validateUser(request: CredentialsRequest?): Boolean? {
        val user = request?.let { userRepository.findByEmail(it.email) }
        var valid: Boolean? = null
        if (request != null) {
            valid = user?.password == request.password
        }
        return valid
    }
}

