package com.grpc.grpcserver.repository

import com.grpc.grpcserver.model.Product
import org.springframework.data.jpa.repository.JpaRepository

interface ProductRepository : JpaRepository<Product, Int> {
    fun findByProductNameContaining(name: String): List<Product>
}
