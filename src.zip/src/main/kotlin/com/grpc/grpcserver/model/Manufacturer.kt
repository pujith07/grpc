package com.grpc.grpcserver.model

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.Table

@Entity
@Table(name = "Manufacturer")
data class Manufacturer(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var manufactureId: Int = 0,
    val manufactureName: String,
    val manufactureOrigin: String,
    val userRatings: Float,
    val noOfProductsAvailable: Int,
    val annualRevenue: Double
)
