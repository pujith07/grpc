package com.grpc.grpcserver.config

import com.grpc.grpcserver.service.GrpcServerService
import io.grpc.Server
import io.grpc.ServerBuilder
import org.springframework.context.ApplicationListener
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.event.ContextRefreshedEvent

@Configuration
class GrpcServerConfig(private val greeterService: GrpcServerService) :
    ApplicationListener<ContextRefreshedEvent> {

    @Bean
    fun grpcServer(): Server {
    return ServerBuilder
    .forPort(50051)
    .addService(greeterService)
    .build()
    }

    override fun onApplicationEvent(event: ContextRefreshedEvent) {
        val server = grpcServer()
        server.start()
        Runtime.getRuntime().addShutdownHook(Thread { server.shutdown() })
    }
}