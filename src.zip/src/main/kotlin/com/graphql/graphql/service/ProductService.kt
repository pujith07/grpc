package com.graphql.graphql.service

import com.graphql.graphql.model.Product


interface ProductService {
    fun getProductByName(name: String): Product?
    fun createProduct(products: List<Product>): List<Product>?
    fun getAllManufacturers(): List<String>
}
