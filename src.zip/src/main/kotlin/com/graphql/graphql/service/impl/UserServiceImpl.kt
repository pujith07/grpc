package com.graphql.graphql.service.impl

import com.graphql.graphql.model.User
import com.graphql.graphql.proto.CredentialsRequest
import com.graphql.graphql.proto.UserGrpc
import com.graphql.graphql.proto.UserGrpcRequest
import com.graphql.graphql.service.GrpcClientService
import com.graphql.graphql.service.UserService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.io.IOException
import java.util.regex.Pattern


@Service
class UserServiceImpl : UserService {

    @Autowired
    private lateinit var grpcClientService: GrpcClientService

    override fun saveUser(users: List<User>): List<User>? {
        val grpcList = mutableListOf<UserGrpc>()
        users.forEach {
            if (!isEmailValid(it.email)) {
                throw IOException("Invalid Email Address :" + it.email)
            }
            grpcList.add(
                UserGrpc.newBuilder()
                    .setUserId(it.userId)
                    .setEmail(it.email)
                    .setGender(it.gender)
                    .setContact(it.contact)
                    .setFirstName(it.firstName)
                    .setLastName(it.lastName)
                    .setPassword(it.password).build()

            )
        }
        val userGrpcRequest = UserGrpcRequest.newBuilder().addAllUsers(grpcList)
        val savedUsers = grpcClientService.saveUser(userGrpcRequest.build())
        val list = mutableListOf<User>()
        savedUsers?.usersList?.forEach {
            list.add(
                User(
                    it.userId,
                    it.firstName,
                    it.lastName,
                    it.gender,
                    it.email,
                    it.contact,
                    it.password
                )
            )
        }

        return list
    }


    override fun validateUser(username: String, password: String): Boolean? {
        val user = grpcClientService.validateCredentials(
            CredentialsRequest.newBuilder()
                .setEmail(username)
                .setPassword(password)
                .build()
        )

        return user
    }

    fun isEmailValid(email: String): Boolean {
        return Pattern.compile(
            "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]|[\\w-]{2,}))@"
                    + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                    + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                    + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                    + "[0-9]{1,2}|25[0-5]|2[0-4][0-9]))|"
                    + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$"
        ).matcher(email).matches()
    }
}


