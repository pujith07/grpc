package com.graphql.graphql.service

import com.google.protobuf.Empty
import com.graphql.graphql.proto.*
import io.grpc.ManagedChannelBuilder
import org.springframework.stereotype.Service

@Service
class GrpcClientService {

    private val channel = ManagedChannelBuilder.forAddress("localhost", 50051)
        .usePlaintext()
        .build()

    private val stub = GraphQLServiceGrpc.newBlockingStub(channel)

    fun saveUser(userGrpcRequest: UserGrpcRequest): UserGrpcResponse? {
        val savedUsers = stub?.saveUser(userGrpcRequest)
        return savedUsers
    }

    fun validateCredentials(request: CredentialsRequest?): Boolean? {
        val user = stub?.validateCredentials(request)
        return user?.isValid
    }

    fun getProductByName(request: ProductByNameRequest?): ProductGrpc? {
        val product = stub?.getProductByName(request)
        return product
    }

    fun saveProduct(request: ProductGrpcRequest?): ProductGrpcResponse? {
        val product = stub?.saveProduct(request)
        return product
    }

    fun getManufacturerByName(request: ManufacturerByNameRequest?): ManufacturerGrpc? {
        val manufacturer = stub?.getManufacturerByName(request)
        return manufacturer
    }

    fun saveManufacturer(request: ManufacturerGrpcRequest?): ManufacturerGrpcResponse? {
        val manufacturer = stub?.saveManufacturer(request)
        return manufacturer
    }

    fun getAllManufacturers(build: Empty): ManufacturerGrpcList? {
        // Use EmptyRequest if that is the correct class
        return stub.getAllManufacturers(EmptyRequest.getDefaultInstance())
    }

    fun shutdown() {
        channel.shutdown()
    }


    }


