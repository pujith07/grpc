package com.graphql.graphql.service

import com.graphql.graphql.model.Manufacturer

interface ManufactureService {
    fun getManufacturerByName(name: String): Manufacturer?
    fun createManufacturer(manufacturers: List<Manufacturer>): List<Manufacturer>
}
