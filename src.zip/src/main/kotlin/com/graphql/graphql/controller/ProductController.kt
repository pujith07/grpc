package com.graphql.graphql.controller

import com.graphql.graphql.model.Product
import com.graphql.graphql.service.ProductService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/products")
class ProductController(private val productService: ProductService) {

    @PostMapping("/create")
    fun createProduct(@RequestBody product: List<Product>): ResponseEntity<List<Product>> {
        val savedProducts = productService.createProduct(product)
        return ResponseEntity(savedProducts, HttpStatus.CREATED)
    }

}
