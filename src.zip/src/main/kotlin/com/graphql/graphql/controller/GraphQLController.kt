package com.graphql.graphql.controller


import com.graphql.graphql.model.Manufacturer
import com.graphql.graphql.model.Product
import com.graphql.graphql.service.ManufactureService
import com.graphql.graphql.service.ProductService
import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.graphql.data.method.annotation.QueryMapping
import org.springframework.stereotype.Controller

@Controller
class GraphQLController (private val productService: ProductService,
private val manufactureService: ManufactureService,
){

    @QueryMapping
    fun searchProductByName(@Argument name: String): Product? =
        productService.getProductByName(name)

    @QueryMapping
    fun getAllManufacturers(): List<String> = productService.getAllManufacturers()

    @QueryMapping
    fun getManufacturerByName(@Argument name: String): Manufacturer? =
        manufactureService.getManufacturerByName(name)
}

