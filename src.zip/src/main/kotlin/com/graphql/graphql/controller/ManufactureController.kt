package com.graphql.graphql.controller
import com.graphql.graphql.service.ManufactureService
import com.graphql.graphql.model.Manufacturer
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/Manufacturer")
class ManufactureController(private val manufacturerService: ManufactureService) {

    @PostMapping("/create")
    fun createManufacturer(@RequestBody manufacturers: List<Manufacturer>): ResponseEntity<List<Manufacturer>> {
        val savedManufacturer = manufacturerService.createManufacturer(manufacturers)
        return ResponseEntity(savedManufacturer, HttpStatus.CREATED)
    }

}
