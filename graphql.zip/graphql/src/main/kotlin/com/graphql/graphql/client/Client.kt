package com.graphql.graphql.client

class Client {

}