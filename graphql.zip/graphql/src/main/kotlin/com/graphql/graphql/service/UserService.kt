package com.graphql.graphql.service

import com.graphql.graphql.model.User

interface UserService {
    fun saveUser(users: List<User>): List<User>?
    fun validateUser(username: String, password: String): Boolean?
}
