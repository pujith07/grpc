package com.graphql.graphql.service.impl

import com.graphql.graphql.model.Product
import com.graphql.graphql.proto.ProductByNameRequest
import com.graphql.graphql.proto.ProductGrpc
import com.graphql.graphql.proto.ProductGrpcRequest
import com.graphql.graphql.service.GrpcClientService
import com.graphql.graphql.service.ProductService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ProductServiceImpl(
) : ProductService {

    @Autowired
    private lateinit var grpcClientService: GrpcClientService

    override fun getProductByName(name: String): Product? {
        val grpcProduct = grpcClientService.getProductByName(
            ProductByNameRequest
                .newBuilder()
                .setProductName(name)
                .build()
        )

        var product: Product? = null
        if (grpcProduct != null) {
            product = Product(
                grpcProduct.productId,
                grpcProduct.productName,
                grpcProduct.productType,
                grpcProduct.manufacturer,
                grpcProduct.unitSoldSoFar,
                grpcProduct.price
            )
        }
        return product
    }

    override fun findAllManufacturers(): List<String> {
        TODO("Not yet implemented")
    }

    override fun createProduct(products: List<Product>): List<Product>? {
        val grpcProductList = mutableListOf<ProductGrpc>()
        products.forEach {
            grpcProductList.add(
                ProductGrpc.newBuilder()
                    .setProductName(it.productName)
                    .setProductType(it.productType)
                    .setManufacturer(it.manufacturer)
                    .setUnitSoldSoFar(it.unitSoldSoFar)
                    .setPrice(it.price).build()
            )
        }
        val productGrpcRequest = ProductGrpcRequest.newBuilder().addAllProducts(grpcProductList)
        val savedProducts = grpcClientService.saveProduct(productGrpcRequest.build())
        val list = mutableListOf<Product>()
        savedProducts?.productsList?.forEach {productGrpc ->
            list.add(
                Product(
                    productGrpc.productId,
                    productGrpc.productName,
                    productGrpc.productType,
                    productGrpc.manufacturer,
                    productGrpc.unitSoldSoFar,
                    productGrpc.price
                )
            )
        }

        return list
    }

}

