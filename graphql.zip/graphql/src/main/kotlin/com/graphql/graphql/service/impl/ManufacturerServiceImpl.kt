package com.graphql.graphql.service.impl

import com.graphql.graphql.model.Manufacturer
import com.graphql.graphql.model.Product
import com.graphql.graphql.proto.ManufacturerByNameRequest
import com.graphql.graphql.proto.ManufacturerGrpc
import com.graphql.graphql.proto.ManufacturerGrpcRequest
import com.graphql.graphql.service.GrpcClientService
import com.graphql.graphql.service.ManufactureService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service


@Service
class ManufacturerServiceImpl(
) : ManufactureService {

    @Autowired
    private lateinit var grpcClientService: GrpcClientService


    override fun getManufacturerByName(name: String): Manufacturer? {
        val grpcManufacturer = grpcClientService.getManufacturerByName(
            ManufacturerByNameRequest.newBuilder()
                .setManufactureName(name)
                .build())

        var manufacturer: Manufacturer? = null
        if (grpcManufacturer != null) {
            manufacturer = Manufacturer(grpcManufacturer.manufactureId,
                grpcManufacturer.manufactureName,
                grpcManufacturer.manufactureOrigin,
                grpcManufacturer.userRatings,
                grpcManufacturer.noOfProductsAvailable,
                grpcManufacturer.annualRevenue)
        }
        return manufacturer
    }

    override fun createManufacturer(manufacturers: List<Manufacturer>): List<Manufacturer> {
        val requestList = mutableListOf<ManufacturerGrpc>()
        manufacturers.forEach { requestList.add(ManufacturerGrpc.newBuilder()
            .setManufactureId(it.manufactureId)
            .setManufactureName(it.manufactureName)
            .setManufactureOrigin(it.manufactureOrigin)
            .setNoOfProductsAvailable(it.noOfProductsAvailable)
            .setAnnualRevenue(it.annualRevenue)
            .setUserRatings(it.userRatings).build())
        }
        val saveManufacturer = grpcClientService.saveManufacturer(
            ManufacturerGrpcRequest.newBuilder().addAllManufacturers(requestList).build())

        val responseList = mutableListOf<Manufacturer>()
        saveManufacturer?.manufacturersList?.forEach { grpcManufacturer ->
            responseList.add(
                Manufacturer(grpcManufacturer.manufactureId,
                    grpcManufacturer.manufactureName,
                    grpcManufacturer.manufactureOrigin,
                    grpcManufacturer.userRatings,
                    grpcManufacturer.noOfProductsAvailable,
                    grpcManufacturer.annualRevenue)
            )

        }
        return responseList;
    }
}
