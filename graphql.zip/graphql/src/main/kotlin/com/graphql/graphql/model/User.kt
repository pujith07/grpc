package com.graphql.graphql.model

data class User(
    var userId: Long = 0,
    var firstName: String = "",
    var lastName: String = "",
    var gender: String = "",
    var email: String = "",
    var contact: String = "",
    var password: String = ""
)
